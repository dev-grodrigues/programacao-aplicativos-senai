package com.senai.medexpress.models;

import com.senai.medexpress.enums.NivelUrgenciaE;

public abstract class Paciente {
	private String cpf;
	private String nome;
	private Integer idade;
	private NivelUrgenciaE urgencia;

	public Paciente(String cpf, String nome, Integer idade, NivelUrgenciaE urgencia) {
		super();
		setCpf(cpf);
		this.nome = nome;
		this.idade = idade;
		this.urgencia = urgencia;
	}

	public Paciente() {
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		if (cpf != null && cpf.length() == 11) {
			this.cpf = cpf;
		} else {
			throw new IllegalArgumentException("CPF INVALIDO!");
		}
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public Integer getIdade() {
		return idade;
	}

	public void setIdade(Integer idade) {
		this.idade = idade;
	}

	public NivelUrgenciaE getUrgencia() {
		return urgencia;
	}

	public void setUrgencia(NivelUrgenciaE urgencia) {
		this.urgencia = urgencia;
	}

	public abstract double calcularCustoAtendimento();

	@Override
	public String toString() {
		return "Paciente [cpf=" + cpf + ", nome=" + nome + ", idade=" + idade + ", urgencia=" + urgencia + "]";
	}



}
