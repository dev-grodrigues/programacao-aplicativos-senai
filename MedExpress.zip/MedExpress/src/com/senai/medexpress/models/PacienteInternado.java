package com.senai.medexpress.models;

import com.senai.medexpress.enums.NivelUrgenciaE;

public class PacienteInternado extends Paciente{

	private Integer diasInternado;
	private Double valorDiaria;
	
	
	public PacienteInternado(String cpf, String nome, Integer idade, NivelUrgenciaE urgencia, Integer diasInternado,
			Double valorDiaria) {
		super(cpf, nome, idade, urgencia);
		this.diasInternado = diasInternado;
		this.valorDiaria = valorDiaria;
	}


	public Integer getDiasInternado() {
		return diasInternado;
	}


	public void setDiasInternado(Integer diasInternado) {
		this.diasInternado = diasInternado;
	}


	public Double getValorDiaria() {
		return valorDiaria;
	}


	public void setValorDiaria(Double valorDiaria) {
		this.valorDiaria = valorDiaria;
	}


	@Override
	public double calcularCustoAtendimento() {
		Double custo = diasInternado * valorDiaria;
		if(diasInternado > 7) {
			custo *= 0.1;
		}
		return custo;
	}
	@Override
	public String toString() {
		return "Paciente [cpf=" + getCpf() + ", nome=" + getNome() + ","
				+ " idade=" + getIdade() + ","
						+ ", urgencia=" + getUrgencia() +", diasInternado="+diasInternado+", valorDiaria="+valorDiaria+"]";
	}



}
