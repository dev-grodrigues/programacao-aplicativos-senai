package com.senai.medexpress.models;

import com.senai.medexpress.enums.NivelUrgenciaE;

public class PacienteEmergencia extends Paciente {

	private Boolean necessitaUTI;

	public PacienteEmergencia(String cpf, String nome, Integer idade, NivelUrgenciaE urgencia, Boolean necessitaUTI) {
		super(cpf, nome, idade, urgencia);
		this.necessitaUTI = necessitaUTI;
	}

	public Boolean getNecessitaUTI() {
		return necessitaUTI;
	}

	public void setNecessitaUTI(Boolean necessitaUTI) {
		this.necessitaUTI = necessitaUTI;
	}

	@Override
	public double calcularCustoAtendimento() {
		double taxaFixa = 200;
		double valorTotal = 0;
		if (getUrgencia() == NivelUrgenciaE.VERMELHO) {
			valorTotal += 300;
		}
		if (necessitaUTI) {
			valorTotal += 500;
		}
		return valorTotal + taxaFixa;
	}

	@Override
	public String toString() {
		return "Paciente [cpf=" + getCpf() + ", nome=" + getNome() + ", " + "idade=" + getIdade() + ", urgencia="
				+ getUrgencia() + " NecessitaUTI:" + necessitaUTI + "]";
	}
}
