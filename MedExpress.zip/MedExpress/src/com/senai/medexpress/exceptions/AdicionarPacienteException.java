package com.senai.medexpress.exceptions;

public class AdicionarPacienteException extends RuntimeException{

	public AdicionarPacienteException(String msg) {
		super(msg);
	}
	
	

}
