package com.senai.medexpress.services;


import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;

import com.senai.medexpress.exceptions.AdicionarPacienteException;
import com.senai.medexpress.models.*;

public class ProntoSocorro implements IFaturavel {
	private List<Paciente> filaAtendimento;

	public ProntoSocorro() {
		this.filaAtendimento = new ArrayList<>();
	}

	public List<Paciente> getFilaAtendimento() {
		return filaAtendimento;
	}
	
	
	public void adicionarPaciente(Paciente p) {
		if(filaAtendimento.contains(p.getCpf())) {
			throw new AdicionarPacienteException("Erro:CPF JÁ CADASTRADO NA FILA");
		}
		filaAtendimento.add(p);
		System.out.println("Paciente:"+p.getNome()+" Adicionado");
	}
	public Paciente atenderProximo() {
		if(filaAtendimento.isEmpty()) {
			throw new NoSuchElementException();
		}		
			filaAtendimento.remove(0);
			
			return filaAtendimento.get(0);
	}

	@Override
	public double processarPagamento() {
		double valorTotalFaturado = 0;
		for (Paciente p : filaAtendimento) {
			valorTotalFaturado += p.calcularCustoAtendimento();
		}
		return valorTotalFaturado;
	}
	
}
