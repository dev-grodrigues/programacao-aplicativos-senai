package com.senai.medexpress.services;

public interface IFaturavel {
	
 public double processarPagamento();
}
