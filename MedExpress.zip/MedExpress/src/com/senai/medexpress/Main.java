package com.senai.medexpress;

import com.senai.medexpress.*;
import com.senai.medexpress.enums.NivelUrgenciaE;
import com.senai.medexpress.models.PacienteEmergencia;
import com.senai.medexpress.models.PacienteInternado;
import com.senai.medexpress.services.ProntoSocorro;

public class Main {

	public static void main(String[] args) {
		ProntoSocorro p = new ProntoSocorro();
		PacienteInternado pInternado = new PacienteInternado("12345678910", "Josefá", 60, NivelUrgenciaE.VERMELHO, 7, 250.0);
		PacienteEmergencia pEmergencia = new PacienteEmergencia("12345678911", "Luciano", 30, NivelUrgenciaE.AMARELO, false);
		p.adicionarPaciente(pInternado);
		p.adicionarPaciente(pEmergencia);
		try {			
			PacienteEmergencia pEmergencia2 = new PacienteEmergencia("123456", "Sales", 30, NivelUrgenciaE.AMARELO, false);
			p.adicionarPaciente(pEmergencia2);
		}catch(IllegalArgumentException e) {
			System.out.println(e.getMessage());
		}
		try {			
			System.out.println(p.processarPagamento());
		}catch(IllegalArgumentException e) {
			throw new IllegalArgumentException("Erro: não há nenhum pagamento para processar");
		}
		try {			
			System.out.println(p.atenderProximo());
		}catch(IllegalArgumentException e) {
			throw new IllegalArgumentException("Erro: não há nenhum paciente na fila");
		}
		
		
	}

}
