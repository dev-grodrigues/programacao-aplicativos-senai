package com.senai.medexpress.enums;

public enum NivelUrgenciaE {
VERDE, AMARELO, VERMELHO
}
