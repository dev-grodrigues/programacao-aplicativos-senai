
public class Teste {

	public static void main(String[] args) {
		ContaBancaria conta = new ContaBancaria("Gabriel", 10);
		conta.exibirDados();
		conta.setSaldo(-1);
		conta.exibirDados();
	}
}
