
public class ContaInvestimento extends ContaBancaria {

	public ContaInvestimento(String numeroConta, String titular, double saldo, double limiteCredito,
			int tempoAberturaAnos) {
		super(numeroConta, titular, saldo, limiteCredito, tempoAberturaAnos);
		
	}

	@Override
	boolean elegivelBonus() {

		return (getSaldo() > 50000 || getTempoAberturaAnos() > 2);
	}

	@Override
	double calcularTaxaManuntencao() {
		double taxaMensal = 20.00;
		return (getSaldo() + taxaMensal);
	}

	@Override
	double calcularRendimentoAnual() {
		double rendimentoAoAno = 0.10;
		if(elegivelBonus()) {
			return ((getSaldo() + 500) * rendimentoAoAno) * getTempoAberturaAnos();
		}else {
			return (getSaldo() * rendimentoAoAno) * getTempoAberturaAnos();
		}
	}
}
