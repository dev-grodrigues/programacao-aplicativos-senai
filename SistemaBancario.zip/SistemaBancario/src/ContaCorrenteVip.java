
public class ContaCorrenteVip extends ContaBancaria {

	public ContaCorrenteVip(String numeroConta, String titular, double saldo, double limiteCredito,
			int tempoAberturaAnos) {
		super(numeroConta, titular, saldo, limiteCredito, tempoAberturaAnos);

	}

	@Override
	boolean elegivelBonus() {
		return (getSaldo() > 10000 || getTempoAberturaAnos() > 5);
	}

	@Override
	double calcularTaxaManuntencao() {
		double taxaMensal = 45.00;
		return (getSaldo() + taxaMensal);
	}

	@Override
	double calcularRendimentoAnual() {
		double rendimentoAoAno = 0.03;
		
		return (getSaldo() * rendimentoAoAno) * getTempoAberturaAnos();
	}

}
