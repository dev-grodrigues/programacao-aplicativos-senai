
public class ContaPoupancaEmpresarial extends ContaBancaria {

	public ContaPoupancaEmpresarial(String numeroConta, String titular, double saldo, double limiteCredito,
			int tempoAberturaAnos) {
		super(numeroConta, titular, saldo, limiteCredito, tempoAberturaAnos);

	}

	@Override
	boolean elegivelBonus() {

		return (getTempoAberturaAnos() > 2);
	}

	@Override
	double calcularTaxaManuntencao() {
		double isentoTaxa = getSaldo();
		return isentoTaxa;
	}

	@Override
	double calcularRendimentoAnual() {
		double rendimentoAoAno = 0.06;		
		return (getSaldo() * rendimentoAoAno) * getTempoAberturaAnos();
	}

}
