import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
abstract class ContaBancaria {
	private static final Set<String>
		CONTAS_REGISTRADAS = ConcurrentHashMap.newKeySet();
	private final String numeroConta;
	
	private String titular;
	private double saldo;
	private double limiteCredito;
	private int tempoAberturaAnos;
	
	public ContaBancaria(String numeroConta, String titular, double saldo, double limiteCredito,
			int tempoAberturaAnos) {
		super();
		if(CONTAS_REGISTRADAS.contains(numeroConta)) {
			throw new IllegalArgumentException("Conta já cadastrada!");
		}
		CONTAS_REGISTRADAS.add(numeroConta);
		this.numeroConta = numeroConta;
		this.titular = titular;
		this.saldo = saldo;
		this.limiteCredito = limiteCredito;
		this.tempoAberturaAnos = tempoAberturaAnos;
	}

	public String getTitular() {
		return titular;
	}

	public void setTitular(String titular) {
		this.titular = titular;
	}

	public double getSaldo() {
		return saldo;
	}

	public void setSaldo(double saldo) {
		this.saldo = saldo;
	}

	public double getLimiteCredito() {
		return limiteCredito;
	}

	public void setLimiteCredito(double limiteCredito) {
		this.limiteCredito = limiteCredito;
	}

	public int getTempoAberturaAnos() {
		return tempoAberturaAnos;
	}

	public void setTempoAberturaAnos(int tempoAberturaAnos) {
		this.tempoAberturaAnos = tempoAberturaAnos;
	}

	public static Set<String> getContasRegistradas() {
		return CONTAS_REGISTRADAS;
	}

	public String getNumeroConta() {
		return numeroConta;
	}
	
	abstract boolean elegivelBonus();
	abstract double calcularTaxaManuntencao();
	abstract double calcularRendimentoAnual();
	
}
