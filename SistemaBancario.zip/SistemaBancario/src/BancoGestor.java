import java.util.ArrayList;
public class BancoGestor {
 ArrayList<ContaBancaria> bradesco = new ArrayList<>();
 public void adicionarConta() {
	 
 }
 public ContaBancaria gerarRelatorioFinanceiro() {
	 return null;
 }
}
